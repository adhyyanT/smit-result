# GPA Scraper - SMIT

This script scrapes all the marks for all subjects and departments of all students for a given exam.

<hr>

### \$ python3 scrapdata.py

This script scraps all result of a given exam. Change the URL inside the script as required.
